# Telegram Windows File Access Bot

A secure, read-only Windows automation agent that allows an authorized Telegram user to browse drives, search files, and download documents remotely from Windows.

---

## Key Features

- **Single Entry Point (`START_TELEGRAM_BOT.bat`)**: Automatically verifies Windows environment, checks or installs Python, validates isolated virtual environment `.venv`, verifies configuration with Telegram API, and starts the bot in background mode.
- **Fail-Closed Security**: Only responds to the single numeric Telegram user ID configured in `config.json` via private chats. Ignores all group chats and unauthorized users.
- **Strict Read-Only Access**: No arbitrary command execution, no remote shell / PowerShell execution, no file deletion, and no uploads to the PC.
- **Path Traversal Protection**: Enforces canonical path resolution (`resolve(strict=True)`), restricts navigation to authorized drive roots, and re-validates paths after opening.
- **Private Callback Navigation**: Filesystem paths are never transmitted in Telegram inline button callbacks. Ephemeral random session keys (`secrets.token_hex`) are mapped in memory.
- **Rotating Logs with Token Redaction**: Automatically strips bot tokens and sensitive endpoints from logs and console output. Uses `RotatingFileHandler` (5 MB per file, 3 backups).
- **Single-Instance Tracking**: Tracks background process via `bot.pid` and Windows API checks to prevent duplicate instances.
- **Automatic Startup**: Optional per-user Windows Task Scheduler task (`TelegramFileBot`) that starts the bot cleanly at sign-in.

---

## Quick Start (One-Click Setup)

1. **Extract or Place the Folder** in a permanent location (e.g. `C:\Tools\TelegramFileBot` or your user folder).
2. **Double-click `START_TELEGRAM_BOT.bat`**:
   - The launcher will detect Python (or offer to download and install official Python 3.11 if missing).
   - If `config.json` is not yet configured, the interactive setup wizard will guide you to enter your **Bot Token** and **Telegram User ID**.
   - Your token will be validated live against `https://api.telegram.org/bot<token>/getMe`.
   - The bot will start in the background and verify health.
3. Open Telegram, open a private chat with your bot, and send `/start`.

---

## Configuration (`config.json`)

If configuring manually or reviewing settings:

```json
{
  "bot_token": "123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ",
  "authorized_user_id": 1247536922,
  "auto_detect_drives": true,
  "allowed_folders": []
}
```

- `bot_token`: Your Telegram bot token obtained from [@BotFather](https://t.me/BotFather).
- `authorized_user_id`: Your numeric Telegram user ID obtained from [@userinfobot](https://t.me/userinfobot).
- `auto_detect_drives`: When `true`, automatically discovers mounted Windows drives (`C:\`, `D:\`, etc.).
- `allowed_folders`: When `auto_detect_drives` is `false`, you can specify an explicit whitelist of folder paths to expose (e.g. `["C:\\Users\\Username\\Documents"]`).

> **Security Note:** Never share your `config.json` or commit it to version control. The template `config.example.json` contains no real secrets.

---

## Telegram Bot Commands

| Command | Description |
| :--- | :--- |
| `/start` or `/help` | Displays help menu and active limits |
| `/browse` or `/folders` | Browse drives and folders using interactive buttons |
| `/drives` | Lists available Windows drives |
| `/search <filename>` | Searches authorized locations (capped at 3,000 folders, 20 results) |
| `/download` | Instructions and quick root selector for downloading files |
| `/status` | Reports bot health, uptime, process ID, memory load, and drive roots |

- **Download Limits:** Telegram Bot API limits transfers to 50 MB; this bot enforces a conservative 45 MB limit. Files exceeding this limit are refused with a clear notification.
- **Pagination:** Directories with many files are paginated (12 items per page) with `◀ Previous` and `Next ▶` buttons.

---

## Background Operation & Management Scripts

| Script | Purpose |
| :--- | :--- |
| `START_TELEGRAM_BOT.bat` | First-run setup, preflight check, and manual start (runs in background). |
| `STOP_TELEGRAM_BOT.bat` | Gracefully terminates the running bot process and clears PID lock. |
| `UNINSTALL_STARTUP.bat` | Completely removes the scheduled task from Windows Task Scheduler. |

### Automatic Startup at Logon

During initial setup, you are prompted to enable automatic startup. You can also manage it at any time:
- To enable: Run `.venv\Scripts\python.exe setup_wizard.py --install-task` (or rerun `START_TELEGRAM_BOT.bat`).
- To disable: Double-click `UNINSTALL_STARTUP.bat`.

> **Important Operating Requirements:**
> For remote access to work:
> 1. The computer must be powered on (not in sleep or hibernation).
> 2. The configured Windows user account must be signed in.
> 3. The computer must have an active internet connection.

---

## Security Architecture

1. **Least-Privilege & No Shell:** No arbitrary code execution, no cmd/PowerShell bridge, and no upload/modify/delete features.
2. **Fail-Closed Authorization:** Any incoming message or callback not originating from `authorized_user_id` in a `private` chat is rejected immediately.
3. **Log Sanitization:** All log handlers use a regex and token redactor (`TokenRedactionFilter`) that scrubs tokens from logs, preventing leaks in `bot.log` and console streams. HTTP transport logging (`httpx`, `httpcore`) is kept at `WARNING` level.
4. **Symlink / TOCTOU Mitigation:** Paths are canonicalized before display and re-verified upon stream opening.

---

## Troubleshooting

- **Check logs:** Review `bot.log` in the application directory for diagnostics (all secrets are redacted).
- **Process already running:** Run `STOP_TELEGRAM_BOT.bat` to terminate any previous or background instances.
- **Bot does not respond:** Confirm your Telegram numeric user ID matches `authorized_user_id` in `config.json` and that you are messaging the bot in a **private chat** (not in a group).
- **Task Scheduler:** The task runs as `TelegramFileBot` under the current user account without elevated admin privileges.
