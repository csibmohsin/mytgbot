@echo off
setlocal
title Telegram File Bot Launcher
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" %*
if errorlevel 1 (
    echo.
    echo [ERROR] Launcher encountered an error.
    pause
    exit /b 1
)

exit /b 0
