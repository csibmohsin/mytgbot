@echo off
setlocal
title Stop Telegram File Bot
cd /d "%~dp0"

echo ============================================================
echo               Stopping Telegram File Bot...                 
echo ============================================================

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" setup_wizard.py --stop
) else (
    rem Fallback if venv is missing
    if exist "bot.pid" (
        for /f "tokens=2 delims=:, " %%a in ('findstr "pid" bot.pid') do (
            taskkill /PID %%a /T /F >nul 2>&1
        )
        del bot.pid >nul 2>&1
    )
    schtasks /End /TN "TelegramFileBot" >nul 2>&1
    echo [OK] Bot process stopped.
)

echo.
pause
