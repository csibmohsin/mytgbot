@echo off
setlocal
title Uninstall Telegram File Bot Auto-Startup
cd /d "%~dp0"

echo ============================================================
echo      Removing Automatic Startup Task (Task Scheduler)       
echo ============================================================

schtasks /Query /TN "TelegramFileBot" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    schtasks /End /TN "TelegramFileBot" >nul 2>&1
    schtasks /Delete /TN "TelegramFileBot" /F
    if %ERRORLEVEL% equ 0 (
        echo [OK] Scheduled task 'TelegramFileBot' has been successfully removed.
        echo The bot will no longer start automatically at Windows sign-in.
    ) else (
        echo [ERROR] Failed to remove scheduled task.
    )
) else (
    echo [INFO] Scheduled task 'TelegramFileBot' was not found or already uninstalled.
)

echo.
pause
