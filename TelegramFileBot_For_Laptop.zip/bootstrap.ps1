# Windows PowerShell bootstrap script for Telegram File Bot
# Provides clean, streamlined 1-100% progress reporting and silent background launching.

$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $ScriptDir

$VenvDir = Join-Path $ScriptDir ".venv"
$VenvPy = Join-Path $VenvDir "Scripts\python.exe"
$ReqFile = Join-Path $ScriptDir "requirements.txt"
$WizardScript = Join-Path $ScriptDir "setup_wizard.py"
$PidFile = Join-Path $ScriptDir "bot.pid"
$SetupLog = Join-Path $ScriptDir "setup.log"

# Handle CLI commands directly (e.g., --status, --stop, --wizard)
if ($args.Count -gt 0) {
    if (Test-Path $VenvPy) {
        & $VenvPy $WizardScript $args[0]
        exit $LASTEXITCODE
    }
}

# Configure console window and UTF-8 output
try {
    $Host.UI.RawUI.WindowTitle = "Telegram File Bot"
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

function Show-Progress([int]$Percent, [string]$Status) {
    $barLength = 20
    $filled = [int]($barLength * $Percent / 100)
    if ($filled -gt $barLength) { $filled = $barLength }
    $empty = $barLength - $filled
    $bar = ("#" * $filled) + ("-" * $empty)
    
    $line = "  [$bar] {0,3}%  {1,-32}" -f $Percent, $Status
    try {
        if ([Console]::CursorLeft -ge 0) {
            [Console]::CursorLeft = 0
            Write-Host -NoNewline $line -ForegroundColor Cyan
            return
        }
    } catch {}
    Write-Host -NoNewline "`r$line" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "  Telegram File Bot" -ForegroundColor White
Write-Host "  --------------------------------------------------" -ForegroundColor Gray

Show-Progress 5 "Initializing..."

# Function to test an interpreter for compatibility (Python 3.10+)
function Test-PythonInterpreter($Path) {
    if (-not (Test-Path $Path)) { return $false }
    try {
        $out = & $Path -c "import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 10) else 1)" 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

# 1. Check if .venv already exists and has dependencies
$NeedsInstall = $true
if (Test-Path $VenvPy) {
    if (Test-PythonInterpreter $VenvPy) {
        try {
            & $VenvPy -c "import telegram" 2>$null
            if ($LASTEXITCODE -eq 0) {
                $NeedsInstall = $false
            }
        } catch {}
    }
}

# 2. Setup Python and dependencies if missing
if ($NeedsInstall) {
    Show-Progress 15 "Detecting Python runtime..."
    $Candidates = @()

    $pyLauncher = Get-Command "py" -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        try {
            $pyPath = & py -3 -c "import sys; print(sys.executable)" 2>$null
            if ($pyPath -and (Test-Path $pyPath)) { $Candidates += $pyPath }
        } catch {}
    }

    $pythonCmds = Get-Command "python" -All -ErrorAction SilentlyContinue
    if ($pythonCmds) {
        foreach ($cmd in $pythonCmds) {
            $src = $cmd.Source
            if ($src -notmatch "WindowsApps") { $Candidates += $src }
        }
    }

    $regPaths = @(
        "HKCU:\Software\Python\PythonCore\*\InstallPath",
        "HKLM:\Software\Python\PythonCore\*\InstallPath"
    )
    foreach ($reg in $regPaths) {
        try {
            $items = Get-ItemProperty -Path $reg -ErrorAction SilentlyContinue
            foreach ($item in $items) {
                $exe = Join-Path $item.ExecutablePath ""
                if ($exe -and (Test-Path $exe)) { $Candidates += $exe }
            }
        } catch {}
    }

    $stdPaths = @(
        "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe",
        "$env:ProgramFiles\Python3*\python.exe"
    )
    foreach ($pat in $stdPaths) {
        $matched = Resolve-Path $pat -ErrorAction SilentlyContinue
        if ($matched) {
            foreach ($m in $matched) { $Candidates += $m.Path }
        }
    }

    $SelectedPython = $null
    foreach ($cand in $Candidates) {
        if (Test-PythonInterpreter $cand) {
            $SelectedPython = $cand
            break
        }
    }

    if (-not $SelectedPython) {
        Show-Progress 20 "Downloading Python 3.11..."
        $installerUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
        $installerPath = Join-Path $env:TEMP "python-3.11.9-amd64-installer.exe"
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13
        
        try {
            Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing
        } catch {
            Write-Host "`n[ERROR] Failed to download Python installer: $_" -ForegroundColor Red
            exit 1
        }

        $sig = Get-AuthenticodeSignature $installerPath
        if ($sig.Status -ne "Valid" -or $sig.SignerCertificate.Subject -notmatch "Python Software Foundation") {
            Remove-Item -Force $installerPath -ErrorAction SilentlyContinue
            Write-Host "`n[ERROR] Installer signature verification failed! Untrusted binary." -ForegroundColor Red
            exit 1
        }

        Show-Progress 35 "Installing Python 3.11..."
        $proc = Start-Process -FilePath $installerPath -ArgumentList "/passive", "InstallAllUsers=0", "PrependPath=1", "Include_pip=1" -Wait -PassThru -WindowStyle Hidden
        Remove-Item -Force $installerPath -ErrorAction SilentlyContinue

        if ($proc.ExitCode -ne 0) {
            Write-Host "`n[ERROR] Python installation failed (code $($proc.ExitCode))." -ForegroundColor Red
            exit 1
        }

        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
        $env:Path = "$userPath;$machinePath"

        $defaultInstall = "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe"
        if (Test-PythonInterpreter $defaultInstall) {
            $SelectedPython = $defaultInstall
        } else {
            Write-Host "`n[ERROR] Installed Python not found at $defaultInstall." -ForegroundColor Red
            exit 1
        }
    }

    Show-Progress 50 "Setting up virtual environment..."
    if (Test-Path $VenvDir) {
        Remove-Item -Recurse -Force $VenvDir -ErrorAction SilentlyContinue
    }
    $venvOutput = & $SelectedPython -m venv $VenvDir 2>&1
    $venvOutput | Out-File -Append -FilePath $SetupLog -Encoding utf8 -ErrorAction SilentlyContinue
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $VenvPy)) {
        # Fallback with --without-pip if ensurepip is restricted
        $venvOutput = & $SelectedPython -m venv --without-pip $VenvDir 2>&1
        $venvOutput | Out-File -Append -FilePath $SetupLog -Encoding utf8 -ErrorAction SilentlyContinue
        if (Test-Path $VenvPy) {
            & $SelectedPython -m ensurepip --default-pip 2>&1 | Out-File -Append -FilePath $SetupLog -Encoding utf8 -ErrorAction SilentlyContinue
        }
    }
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $VenvPy)) {
        Write-Host "`n[ERROR] Failed to create virtual environment." -ForegroundColor Red
        if ($venvOutput) {
            Write-Host "Details: $venvOutput" -ForegroundColor Yellow
        }
        exit 1
    }

    Show-Progress 68 "Installing bot dependencies..."
    $pipOutput = & $VenvPy -m pip install --no-cache-dir -q -r $ReqFile 2>&1
    $pipOutput | Out-File -Append -FilePath $SetupLog -Encoding utf8 -ErrorAction SilentlyContinue
    if ($LASTEXITCODE -ne 0) {
        Write-Host "`n[ERROR] Dependency installation failed. Check setup.log for details." -ForegroundColor Red
        if ($pipOutput) {
            Write-Host "Details: $pipOutput" -ForegroundColor Yellow
        }
        exit 1
    }
} else {
    Show-Progress 40 "Environment verified..."
}

# 3. Verify Configuration
Show-Progress 75 "Verifying configuration..."
$verifyOutput = & $VenvPy $WizardScript 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "`n[ERROR] Configuration check failed: $verifyOutput" -ForegroundColor Red
    exit 1
}

# 4. Check if Bot is Already Running
$checkOutput = & $VenvPy $WizardScript --check-running 2>&1
if ($LASTEXITCODE -eq 0) {
    Show-Progress 100 "Bot is already running!"
    Write-Host "`n"
    Start-Sleep -Milliseconds 1200
    exit 0
}

# 5. Launch Bot in Background Mode
Show-Progress 90 "Launching background service..."
$startOutput = & $VenvPy $WizardScript --start 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "`n[ERROR] Bot failed to start: $startOutput" -ForegroundColor Red
    exit 1
}

# 6. Complete and close cleanly
Show-Progress 100 "Bot is Online in Background!"
Write-Host "`n"
Start-Sleep -Milliseconds 1200
exit 0
