import asyncio
import atexit
import ctypes
import html
import json
import logging
import logging.handlers
import os
import re
import secrets
import signal
import string
import sys
import time
from datetime import datetime
from pathlib import Path
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    KeyboardButton,
    BotCommand
)
from telegram.constants import ChatAction
from telegram.request import HTTPXRequest
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters
)

BASE = Path(__file__).resolve().parent
CONFIG = BASE / 'config.json'
PID_FILE = BASE / 'bot.pid'
LOG_FILE = BASE / 'bot.log'
MAX_BYTES = 45 * 1024 * 1024  # 45 MB safety limit (Telegram API limit is 50 MB)
PAGE_SIZE = 10  # 10 items per page for clean mobile display
START_TIME = time.time()

# Persistent bottom menu for 1-tap access
MAIN_KEYBOARD = ReplyKeyboardMarkup(
    [
        [KeyboardButton("💽 Browse Drives"), KeyboardButton("⚡ Quick Folders")],
        [KeyboardButton("🔍 Search Files"), KeyboardButton("📊 PC Status")]
    ],
    resize_keyboard=True,
    is_persistent=True
)

# File extension to rich icon mapping
FILE_ICONS = {
    # Documents
    '.pdf': '📕', '.doc': '📘', '.docx': '📘', '.txt': '📄', '.rtf': '📄',
    '.xls': '📊', '.xlsx': '📊', '.csv': '📊', '.ppt': '📈', '.pptx': '📈',
    # Media
    '.png': '🖼️', '.jpg': '🖼️', '.jpeg': '🖼️', '.gif': '🖼️', '.webp': '🖼️', '.svg': '🖼️',
    '.mp4': '🎬', '.mkv': '🎬', '.avi': '🎬', '.mov': '🎬', '.webm': '🎬',
    '.mp3': '🎵', '.wav': '🎵', '.flac': '🎵', '.m4a': '🎵', '.ogg': '🎵',
    # Archives
    '.zip': '📦', '.rar': '📦', '.7z': '📦', '.tar': '📦', '.gz': '📦', '.iso': '💿',
    # Code & Configuration
    '.py': '🐍', '.js': '📜', '.ts': '📜', '.html': '🌐', '.css': '🎨',
    '.json': '⚙️', '.xml': '⚙️', '.yml': '⚙️', '.yaml': '⚙️', '.sql': '🗄️',
    '.bat': '⚡', '.ps1': '⚡', '.sh': '⚡', '.cpp': '💻', '.c': '💻', '.h': '💻',
    # Executable / Binary
    '.exe': '⚙️', '.msi': '⚙️', '.dll': '🧩'
}


def format_size(size_bytes: int) -> str:
    """Format bytes into readable units."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def get_drive_details(p: Path) -> tuple[str, str]:
    """Get drive name and free/total storage string."""
    raw = str(p)
    letter = raw[:2].upper()
    if os.name == 'nt':
        try:
            free_bytes = ctypes.c_ulonglong()
            total_bytes = ctypes.c_ulonglong()
            total_free = ctypes.c_ulonglong()
            if ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                ctypes.c_wchar_p(raw),
                ctypes.byref(free_bytes),
                ctypes.byref(total_bytes),
                ctypes.byref(total_free)
            ):
                free_gb = free_bytes.value / (1024 ** 3)
                total_gb = total_bytes.value / (1024 ** 3)
                return f"Local Disk ({letter})", f"{free_gb:.1f} GB free of {total_gb:.1f} GB"
        except Exception:
            pass
    return f"Drive ({letter})", raw


def get_item_label(p: Path) -> str:
    """Format a clean button label with appropriate icon and file size."""
    if p.is_dir():
        if p.name == "" or p == p.anchor:
            title, space = get_drive_details(p)
            free_match = re.search(r'([\d\.]+\s*GB free)', space)
            free_text = f" [{free_match.group(1)}]" if free_match else ""
            return f"💽 {title}{free_text}"
        return f"📁 {p.name}"

    icon = FILE_ICONS.get(p.suffix.lower(), "📄")
    try:
        size = p.stat().st_size
        size_str = format_size(size)
        if size > MAX_BYTES:
            return f"{icon} {p.name} [{size_str} ⚠️]"[:55]
        return f"{icon} {p.name} [{size_str}]"[:55]
    except (OSError, PermissionError):
        return f"{icon} {p.name}"[:55]


class TokenRedactionFilter(logging.Filter):
    """Filter that strips Telegram bot tokens from all log messages."""
    def __init__(self, token: str = ""):
        super().__init__()
        self.token = token
        self.pattern = re.compile(r'bot\d+:[A-Za-z0-9_-]+')

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            if self.token and self.token in record.msg:
                record.msg = record.msg.replace(self.token, "[REDACTED_TOKEN]")
            record.msg = self.pattern.sub("bot[REDACTED_TOKEN]", record.msg)
        if record.args:
            cleaned_args = []
            for arg in record.args:
                if isinstance(arg, str):
                    if self.token and self.token in arg:
                        arg = arg.replace(self.token, "[REDACTED_TOKEN]")
                    arg = self.pattern.sub("bot[REDACTED_TOKEN]", arg)
                cleaned_args.append(arg)
            record.args = tuple(cleaned_args)
        return True


def setup_logging(token: str) -> logging.Logger:
    """Setup rotating file logger and console logger with token redaction."""
    logger = logging.getLogger("filebot")
    logger.setLevel(logging.INFO)

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    redact_filter = TokenRedactionFilter(token)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding='utf-8'
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(redact_filter)

    logger.handlers.clear()
    logger.addHandler(file_handler)

    if sys.stdout is not None:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.addFilter(redact_filter)
        logger.addHandler(console_handler)

    root_logger = logging.getLogger()
    for handler in root_logger.handlers:
        handler.addFilter(redact_filter)

    return logger


def is_bot_process_alive(pid: int) -> bool:
    """Check if process with given PID exists and is a Python process on Windows."""
    if pid <= 0:
        return False
    if os.name != 'nt':
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    h_process = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h_process:
        return False
    try:
        exit_code = ctypes.c_ulong()
        if not ctypes.windll.kernel32.GetExitCodeProcess(h_process, ctypes.byref(exit_code)):
            return False
        if exit_code.value != STILL_ACTIVE:
            return False
        buf = ctypes.create_unicode_buffer(1024)
        size = ctypes.c_ulong(len(buf))
        if ctypes.windll.kernel32.QueryFullProcessImageNameW(h_process, 0, buf, ctypes.byref(size)):
            return "python" in buf.value.lower()
        return True
    finally:
        ctypes.windll.kernel32.CloseHandle(h_process)


def check_and_acquire_pid() -> None:
    """Ensure single instance using PID tracking and Windows process check."""
    my_pid = os.getpid()
    if PID_FILE.exists():
        try:
            data = json.loads(PID_FILE.read_text(encoding='utf-8-sig'))
            existing_pid = int(data.get('pid', 0))
            if existing_pid > 0 and existing_pid != my_pid and is_bot_process_alive(existing_pid):
                log.warning('Another instance of Telegram File Bot is already running (PID: %d).', existing_pid)
                sys.exit(0)
        except Exception:
            pass

    try:
        PID_FILE.write_text(json.dumps({
            "pid": my_pid,
            "start_time": datetime.now().isoformat(),
            "interpreter": sys.executable
        }), encoding='utf-8')
    except Exception as e:
        log.warning("Could not write PID file: %s", e)

    def cleanup_pid():
        try:
            if PID_FILE.exists():
                data = json.loads(PID_FILE.read_text(encoding='utf-8-sig'))
                if int(data.get('pid', 0)) == my_pid:
                    PID_FILE.unlink()
        except Exception:
            pass

    atexit.register(cleanup_pid)
    try:
        signal.signal(signal.SIGINT, lambda s, f: sys.exit(0))
        signal.signal(signal.SIGTERM, lambda s, f: sys.exit(0))
    except (ValueError, AttributeError):
        pass


def detect_roots(data: dict) -> list[Path]:
    """Auto-detect mounted Windows drive roots or load configured folders."""
    if data.get('auto_detect_drives', False):
        if os.name != 'nt':
            raise ValueError('auto_detect_drives is supported on Windows only')
        mask = ctypes.windll.kernel32.GetLogicalDrives()
        roots = []
        for index, letter in enumerate(string.ascii_uppercase):
            if mask & (1 << index):
                candidate = Path(f'{letter}:\\')
                try:
                    if candidate.is_dir():
                        roots.append(candidate.resolve(strict=True))
                except (OSError, RuntimeError):
                    pass
        return roots

    roots = []
    for raw in data.get('allowed_folders', []):
        p = Path(os.path.expandvars(raw)).expanduser().resolve(strict=True)
        if not p.is_dir():
            raise ValueError(f'Not a folder: {p}')
        roots.append(p)
    return roots


def get_device_identity() -> str:
    """Automatically detect the Windows computer name and hardware model."""
    hostname = os.environ.get('COMPUTERNAME') or "Windows PC"
    if os.name == 'nt':
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS")
            model, _ = winreg.QueryValueEx(key, "SystemProductName")
            if model and model.strip() and model.strip().lower() not in (
                "system product name", "to be filled by o.e.m.", "default string", "chassis manufacture"
            ):
                return f"{hostname} ({model.strip()})"
        except Exception:
            pass
    return hostname


def load_config():
    """Load and strictly validate bot configuration."""
    if not CONFIG.exists():
        raise FileNotFoundError(f"Missing config.json at {CONFIG}. Run START_TELEGRAM_BOT.bat or setup_wizard.py.")
    data = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
    token = str(data.get('bot_token', '')).strip()
    uid = int(data.get('authorized_user_id', 0))
    raw_device = str(data.get('device_name', '')).strip()
    device_name = raw_device if raw_device else get_device_identity()

    if not token or token.startswith('REPLACE_') or uid <= 0:
        raise ValueError('Invalid bot_token or authorized_user_id in config.json. Run setup_wizard.py.')
    roots = detect_roots(data)
    if not roots:
        raise ValueError('No accessible drives/folders found. Check config.json and Windows drive availability.')
    return token, uid, roots, device_name


TOKEN, AUTHORIZED_ID, ROOTS, DEVICE_NAME = load_config()
log = setup_logging(TOKEN)


def allowed(p: Path) -> bool:
    """Strictly test whether a path resolves within authorized drive roots."""
    try:
        resolved = p.resolve(strict=True)
        return any(resolved == root or root in resolved.parents for root in ROOTS)
    except (OSError, RuntimeError, PermissionError):
        return False


def get_entry(context: ContextTypes.DEFAULT_TYPE, key: str) -> Path | None:
    """Retrieve Path from ephemeral random session key and revalidate."""
    entry = context.user_data.get('entries', {}).get(key)
    if not entry:
        return None
    p = Path(entry)
    return p if allowed(p) else None


def make_entries(context: ContextTypes.DEFAULT_TYPE, paths: list[Path]) -> list[InlineKeyboardButton]:
    """Map filesystem paths to ephemeral random tokens in user_data with rich labels."""
    entries = context.user_data.setdefault('entries', {})
    buttons = []
    for p in paths:
        key = secrets.token_hex(8)
        entries[key] = str(p)
        label = get_item_label(p)
        buttons.append(InlineKeyboardButton(label, callback_data='open:' + key))
    return buttons


def get_user_shortcuts() -> list[tuple[str, Path]]:
    """Return common user shortcuts (Desktop, Downloads, Documents, etc.)."""
    user_profile = Path(os.environ.get('USERPROFILE', 'C:\\Users\\Default'))
    shortcuts = []
    candidates = [
        ("🖥️ Desktop", user_profile / "Desktop"),
        ("📥 Downloads", user_profile / "Downloads"),
        ("📄 Documents", user_profile / "Documents"),
        ("🖼️ Pictures", user_profile / "Pictures"),
        ("🎬 Videos", user_profile / "Videos"),
        ("🎵 Music", user_profile / "Music"),
    ]
    for label, p in candidates:
        if p.exists() and p.is_dir() and allowed(p):
            shortcuts.append((label, p))
    return shortcuts


def directory_view(context: ContextTypes.DEFAULT_TYPE, folder: Path, page: int = 0) -> tuple[str, InlineKeyboardMarkup]:
    """Generate paginated directory listing with inline navigation."""
    if not allowed(folder) or not folder.is_dir():
        raise PermissionError('Folder is not permitted or does not exist.')

    try:
        raw_items = [p for p in folder.iterdir() if allowed(p)]
    except (PermissionError, OSError) as e:
        raise PermissionError(f'Access denied: {e}')

    dirs = sorted([p for p in raw_items if p.is_dir()], key=lambda p: p.name.lower())
    files = sorted([p for p in raw_items if not p.is_dir()], key=lambda p: p.name.lower())
    items = dirs + files

    total_pages = max(1, (len(items) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start_idx = page * PAGE_SIZE
    page_items = items[start_idx:start_idx + PAGE_SIZE]

    buttons = make_entries(context, page_items)
    rows = [[b] for b in buttons]

    # Pagination navigation bar
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton('◀ Prev', callback_data=f'page:{page-1}'))
    if total_pages > 1:
        nav.append(InlineKeyboardButton(f'📄 {page+1} / {total_pages}', callback_data='noop'))
    if start_idx + PAGE_SIZE < len(items):
        nav.append(InlineKeyboardButton('Next ▶', callback_data=f'page:{page+1}'))
    if nav:
        rows.append(nav)

    # Action bar
    action_row = []
    if folder.parent and allowed(folder.parent) and folder.parent != folder:
        entries = context.user_data.setdefault('entries', {})
        up_key = secrets.token_hex(8)
        entries[up_key] = str(folder.parent)
        action_row.append(InlineKeyboardButton('⬆️ Up', callback_data='open:' + up_key))

    entries = context.user_data.setdefault('entries', {})
    ref_key = secrets.token_hex(8)
    entries[ref_key] = str(folder)
    action_row.append(InlineKeyboardButton('🔄 Refresh', callback_data='open:' + ref_key))
    action_row.append(InlineKeyboardButton('💽 Drives', callback_data='roots'))
    rows.append(action_row)

    context.user_data['current_folder'] = str(folder)
    context.user_data['current_page'] = page

    folder_escaped = html.escape(str(folder))
    text = (
        f"📂 <b>Directory Browser</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📍 <b>Location:</b> <code>{folder_escaped}</code>\n"
        f"📊 <b>Contents:</b> {len(dirs)} folder(s), {len(files)} file(s)\n"
        f"━━━━━━━━━━━━━━━━━━━━"
    )
    return text, InlineKeyboardMarkup(rows)


def file_details_view(context: ContextTypes.DEFAULT_TYPE, file_path: Path) -> tuple[str, InlineKeyboardMarkup]:
    """Generate a rich file information card with a download action button."""
    try:
        stat = file_path.stat()
        size_bytes = stat.st_size
        size_str = format_size(size_bytes)
        mod_time = datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
    except (OSError, PermissionError):
        size_bytes = 0
        size_str = "Unknown"
        mod_time = "Unknown"

    icon = FILE_ICONS.get(file_path.suffix.lower(), "📄")
    entries = context.user_data.setdefault('entries', {})
    dl_key = secrets.token_hex(8)
    entries[dl_key] = str(file_path)

    buttons = []
    if size_bytes <= MAX_BYTES:
        buttons.append([InlineKeyboardButton(f"⬇️ Download File ({size_str})", callback_data=f"dl:{dl_key}")])
    else:
        buttons.append([InlineKeyboardButton("⚠️ File Exceeds 45 MB Limit", callback_data="noop")])

    # Back button to parent folder
    parent_folder = file_path.parent
    if allowed(parent_folder):
        up_key = secrets.token_hex(8)
        entries[up_key] = str(parent_folder)
        buttons.append([
            InlineKeyboardButton("⬅️ Back to Folder", callback_data="open:" + up_key),
            InlineKeyboardButton("💽 Drives", callback_data="roots")
        ])
    else:
        buttons.append([InlineKeyboardButton("💽 Drives", callback_data="roots")])

    file_escaped = html.escape(file_path.name)
    parent_escaped = html.escape(str(file_path.parent))
    text = (
        f"{icon} <b>File Information Card</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🏷️ <b>Filename:</b> <code>{file_escaped}</code>\n"
        f"📦 <b>File Size:</b> {size_str}\n"
        f"🕒 <b>Last Modified:</b> {mod_time}\n"
        f"📍 <b>Location:</b> <code>{parent_escaped}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━"
    )
    return text, InlineKeyboardMarkup(buttons)


async def authorized(update: Update) -> bool:
    """Fail-closed authorization check. Rejects any non-matching user or non-private chat."""
    user = update.effective_user
    chat = update.effective_chat

    if not user or user.id != AUTHORIZED_ID or not chat or chat.type != 'private':
        user_id = getattr(user, 'id', 'Unknown')
        log.warning('Unauthorized access attempt rejected from user=%s (chat_type=%s)', user_id, getattr(chat, 'type', 'None'))
        if update.callback_query:
            try:
                await update.callback_query.answer('⛔ Access Denied.', show_alert=True)
            except Exception:
                pass
        elif update.message:
            try:
                await update.message.reply_text('⛔ <b>Access Denied</b>\nThis bot is private and restricted.', parse_mode="HTML")
            except Exception:
                pass
        return False
    return True


async def render_or_edit(q, text: str, markup: InlineKeyboardMarkup):
    """Update message in-place if possible, otherwise send a new message."""
    try:
        await q.edit_message_text(text, reply_markup=markup, parse_mode="HTML")
    except Exception:
        await q.message.reply_text(text, reply_markup=markup, parse_mode="HTML")


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /start and /help - display instant machine dashboard with direct access buttons."""
    if not await authorized(update):
        return

    # 1. Drive buttons
    buttons = make_entries(context, ROOTS)
    rows = [[b] for b in buttons]

    # 2. Direct folder shortcuts (Desktop, Downloads, Documents, Pictures)
    shortcuts = get_user_shortcuts()
    entries = context.user_data.setdefault('entries', {})
    shortcut_row = []
    for label, path in shortcuts[:4]:
        key = secrets.token_hex(8)
        entries[key] = str(path)
        shortcut_row.append(InlineKeyboardButton(label, callback_data="open:" + key))
        if len(shortcut_row) == 2:
            rows.append(shortcut_row)
            shortcut_row = []
    if shortcut_row:
        rows.append(shortcut_row)

    # 3. Action buttons
    rows.append([
        InlineKeyboardButton('🔍 Search Files', callback_data='guide_search'),
        InlineKeyboardButton('📊 PC Status', callback_data='view_status')
    ])

    msg = (
        f"🖥️ <b>{html.escape(DEVICE_NAME)}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🟢 <b>Status:</b> Online & Ready\n"
        "⚡ <b>Direct Access:</b> Tap any drive or folder below to browse:\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )

    await update.message.reply_text(
        msg,
        reply_markup=InlineKeyboardMarkup(rows),
        parse_mode="HTML"
    )
    # Also attach bottom persistent keyboard
    await update.message.reply_text(
        "👇 <b>Control Panel</b> (Or use the quick menu below):",
        reply_markup=MAIN_KEYBOARD,
        parse_mode="HTML"
    )


async def shortcuts_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /shortcuts - quick access to common user directories."""
    if not await authorized(update):
        return
    await send_shortcuts_message(update.message.reply_text, context)


async def send_shortcuts_message(send_func, context: ContextTypes.DEFAULT_TYPE, q=None):
    """Display quick folder shortcuts."""
    shortcuts = get_user_shortcuts()
    entries = context.user_data.setdefault('entries', {})
    rows = []
    current_row = []

    for label, path in shortcuts:
        key = secrets.token_hex(8)
        entries[key] = str(path)
        current_row.append(InlineKeyboardButton(label, callback_data="open:" + key))
        if len(current_row) == 2:
            rows.append(current_row)
            current_row = []
    if current_row:
        rows.append(current_row)

    rows.append([InlineKeyboardButton('💽 All Drives', callback_data='roots')])

    text = (
        f"⚡ <b>Quick Folders — {html.escape(DEVICE_NAME)}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Instant 1-tap shortcuts to your most used folders:\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )
    markup = InlineKeyboardMarkup(rows)
    if q:
        await render_or_edit(q, text, markup)
    else:
        await send_func(text, reply_markup=markup, parse_mode="HTML")


async def drives_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /drives, /folders, /browse - show storage drives."""
    if not await authorized(update):
        return
    await send_roots_message(update.message.reply_text, context)


async def send_roots_message(send_func, context: ContextTypes.DEFAULT_TYPE, q=None):
    """Display available storage drives in a clean format."""
    buttons = make_entries(context, ROOTS)
    rows = [[b] for b in buttons]
    rows.append([
        InlineKeyboardButton('⚡ Quick Folders', callback_data='shortcuts'),
        InlineKeyboardButton('🔍 Search Files', callback_data='guide_search')
    ])
    rows.append([InlineKeyboardButton('📊 PC Status', callback_data='view_status')])

    text = (
        f"💽 <b>Storage Manager — {html.escape(DEVICE_NAME)}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Select a drive below to explore files and folders:\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )
    markup = InlineKeyboardMarkup(rows)
    if q:
        await render_or_edit(q, text, markup)
    else:
        await send_func(text, reply_markup=markup, parse_mode="HTML")


async def download_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /download - instructions and drive picker."""
    if not await authorized(update):
        return
    msg = (
        f"📥 <b>Download Files — {html.escape(DEVICE_NAME)}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "To retrieve a file from your Windows PC:\n"
        "1. Tap <b>💽 Browse Drives</b> or <b>⚡ Quick Folders</b> below.\n"
        "2. Tap any file to view its details and download it.\n"
        "3. Or just type any filename into the chat to search directly.\n\n"
        "⚠️ <i>Telegram transfers are capped at 45 MB per file.</i>\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )
    buttons = make_entries(context, ROOTS)
    rows = [[b] for b in buttons]
    await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")


async def get_status_text() -> str:
    """Generate formatted system status text."""
    uptime_sec = int(time.time() - START_TIME)
    hours, rem = divmod(uptime_sec, 3600)
    minutes, seconds = divmod(rem, 60)
    uptime_str = f"{hours}h {minutes}m {seconds}s"

    mem_info = "N/A"
    if os.name == 'nt':
        try:
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]
            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            total_gb = stat.ullTotalPhys / (1024 ** 3)
            free_gb = stat.ullAvailPhys / (1024 ** 3)
            mem_info = f"{free_gb:.1f} GB free of {total_gb:.1f} GB ({stat.dwMemoryLoad}% load)"
        except Exception:
            pass

    drive_lines = []
    for r in ROOTS:
        title, space = get_drive_details(r)
        drive_lines.append(f"• <b>{title}:</b> {space}")
    drives_block = "\n".join(drive_lines)

    return (
        f"🖥️ <b>Workstation Status — {html.escape(DEVICE_NAME)}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🟢 <b>Status:</b> Online & Ready\n"
        f"💻 <b>Device:</b> <code>{html.escape(DEVICE_NAME)}</code>\n"
        f"⏱️ <b>Uptime:</b> {uptime_str}\n"
        f"🆔 <b>Process ID:</b> <code>{os.getpid()}</code>\n"
        f"🧠 <b>Memory:</b> {mem_info}\n\n"
        f"💽 <b>Storage Drives:</b>\n"
        f"{drives_block}\n\n"
        f"🕒 <b>Host Time:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )


async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /status - report application health and diagnostics."""
    if not await authorized(update):
        return
    text = await get_status_text()
    markup = InlineKeyboardMarkup([[
        InlineKeyboardButton('💽 Browse Drives', callback_data='roots'),
        InlineKeyboardButton('🔄 Refresh', callback_data='view_status')
    ]])
    await update.message.reply_text(text, reply_markup=markup, parse_mode="HTML")


async def execute_search(term: str, update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute search across roots and display interactive results."""
    term = term.strip()
    if len(term) < 2:
        await update.message.reply_text(
            "💡 <b>Search Usage:</b>\nPlease enter at least 2 characters to search.",
            parse_mode="HTML"
        )
        return

    term_escaped = html.escape(term)
    status_msg = await update.message.reply_text(
        f"🔍 <b>Searching for</b> <code>{term_escaped}</code> across drives...",
        parse_mode="HTML"
    )
    term_lower = term.lower()
    results = []
    visited_dirs = 0

    try:
        for root in ROOTS:
            for current, dirs, files in os.walk(root, followlinks=False):
                current_p = Path(current)
                if not allowed(current_p):
                    dirs[:] = []
                    continue

                safe_dirs = []
                for d in dirs:
                    try:
                        dp = current_p / d
                        if allowed(dp):
                            safe_dirs.append(d)
                    except (OSError, PermissionError):
                        pass
                dirs[:] = safe_dirs

                visited_dirs += 1
                if visited_dirs > 3000:
                    break

                for name in files:
                    if term_lower in name.lower():
                        p = current_p / name
                        if allowed(p):
                            results.append(p)
                            if len(results) >= 20:
                                break

                if len(results) >= 20 or visited_dirs > 3000:
                    break
            if len(results) >= 20 or visited_dirs > 3000:
                break
    except Exception as exc:
        log.warning("Search error: %s", exc)

    if not results:
        await status_msg.edit_text(
            f"🔍 <b>Search Results</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"No matching files found for <code>{term_escaped}</code> (searched {visited_dirs:,} folders).\n"
            f"━━━━━━━━━━━━━━━━━━━━",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('💽 Back to Drives', callback_data='roots')]]),
            parse_mode="HTML"
        )
        return

    buttons = make_entries(context, results)
    rows = [[b] for b in buttons]
    rows.append([InlineKeyboardButton('💽 Back to Drives', callback_data='roots')])
    await status_msg.edit_text(
        f"🔍 <b>Search Results</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Found <b>{len(results)}</b> match(es) for <code>{term_escaped}</code> (searched {visited_dirs:,} folders):\n"
        f"Tap any file to view details or download:\n"
        f"━━━━━━━━━━━━━━━━━━━━",
        reply_markup=InlineKeyboardMarkup(rows),
        parse_mode="HTML"
    )


async def search_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /search <filename> - search within authorized folders."""
    if not await authorized(update):
        return
    term = ' '.join(context.args).strip()
    if not term:
        await update.message.reply_text(
            "🔍 <b>Search Files</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Type: <code>/search filename</code>\n"
            "Or simply send any text message (e.g. <code>report</code>, <code>.png</code>) to search instantly!",
            parse_mode="HTML"
        )
        return
    await execute_search(term, update, context)


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages from user or custom keyboard taps."""
    if not await authorized(update):
        return

    text = (update.message.text or '').strip()
    if text == "💽 Browse Drives":
        await send_roots_message(update.message.reply_text, context)
    elif text == "⚡ Quick Folders":
        await send_shortcuts_message(update.message.reply_text, context)
    elif text == "📊 PC Status":
        await status_cmd(update, context)
    elif text == "🔍 Search Files":
        await update.message.reply_text(
            "🔍 <b>Instant File Search</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Simply send the name of the file or keyword you want to search for.\n\n"
            "Examples: <code>report</code>, <code>invoice</code>, <code>.pdf</code>, <code>photo</code>",
            parse_mode="HTML"
        )
    else:
        # Treat any plain text query as a file search
        await execute_search(text, update, context)


async def trigger_download(q, p: Path):
    """Handle the actual download and upload of a file with rich caption and progress."""
    try:
        size = p.stat().st_size
        if size > MAX_BYTES:
            size_str = format_size(size)
            p_escaped = html.escape(p.name)
            await q.message.reply_text(
                f"⚠️ <b>File Exceeds Limit</b>\n"
                f"<code>{p_escaped}</code> is <b>{size_str}</b>.\n"
                f"Telegram transfers are limited to 45 MB.",
                parse_mode="HTML"
            )
            return

        size_str = format_size(size)
        p_escaped = html.escape(p.name)
        notify_msg = await q.message.reply_text(
            f"⏳ <b>Uploading</b> <code>{p_escaped}</code> ({size_str})...",
            parse_mode="HTML"
        )

        try:
            await q.message.chat.send_action(action=ChatAction.UPLOAD_DOCUMENT)
        except Exception:
            pass

        with p.open('rb') as stream:
            if not allowed(p):
                raise PermissionError('Path was moved outside allowed directories during transfer.')
            caption = f"📄 <b>{p_escaped}</b> ({size_str})\n📍 <code>{html.escape(str(p.parent))}</code>"
            await q.message.reply_document(
                document=stream,
                filename=p.name,
                caption=caption,
                parse_mode="HTML",
                read_timeout=180,
                write_timeout=180
            )

        try:
            await notify_msg.delete()
        except Exception:
            pass
        log.info('Sent file %s (%d bytes) to authorized user', p.name, size)
    except (OSError, PermissionError) as exc:
        log.warning('File access failed for %s: %s', p.name if p else 'unknown', exc)
        await q.message.reply_text(
            f"🚫 <b>Access Denied or File Locked</b>\n"
            f"Unable to access <code>{html.escape(p.name if p else '')}</code>.\n"
            f"The file may be in use by another program or protected by Windows permissions.",
            parse_mode="HTML"
        )
    except Exception:
        log.exception('File transfer failed')
        await q.message.reply_text(
            f"❌ <b>Transfer Failed</b>\nAn error occurred while uploading. Check <code>bot.log</code> for details.",
            parse_mode="HTML"
        )


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle inline button callback queries with in-place rendering."""
    if not await authorized(update):
        return

    q = update.callback_query
    await q.answer()
    data = q.data or ''

    if data == 'noop':
        return

    if data == 'roots':
        await send_roots_message(q.message.reply_text, context, q=q)
        return

    if data == 'shortcuts':
        await send_shortcuts_message(q.message.reply_text, context, q=q)
        return

    if data == 'view_status':
        text = await get_status_text()
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton('💽 Browse Drives', callback_data='roots'),
            InlineKeyboardButton('🔄 Refresh', callback_data='view_status')
        ]])
        await render_or_edit(q, text, markup)
        return

    if data == 'guide_search':
        text = (
            "🔍 <b>How to Search Files</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Simply type any filename into the chat directly!\n\n"
            "Examples:\n"
            "• <code>resume</code>\n"
            "• <code>.pdf</code>\n"
            "• <code>photos</code>\n"
            "━━━━━━━━━━━━━━━━━━━━"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton('💽 Back to Drives', callback_data='roots')]])
        await render_or_edit(q, text, markup)
        return

    if data.startswith('page:'):
        folder_str = context.user_data.get('current_folder', '')
        if not folder_str:
            await q.message.reply_text('⚠️ Session expired. Use <b>💽 Browse Drives</b> to start again.', parse_mode="HTML")
            return
        folder = Path(folder_str)
        try:
            page_num = int(data.split(':')[1])
            text, markup = directory_view(context, folder, page_num)
            await render_or_edit(q, text, markup)
        except (OSError, ValueError, PermissionError) as e:
            log.warning("Paging error on %s: %s", folder, e)
            await q.message.reply_text('⚠️ Folder unavailable or access denied.', parse_mode="HTML")
        return

    # Direct download from file card
    if data.startswith('dl:'):
        key = data[3:]
        p = get_entry(context, key)
        if p is None or not p.is_file():
            await q.message.reply_text('⚠️ File link expired. Please navigate to the folder again.', parse_mode="HTML")
            return
        await trigger_download(q, p)
        return

    if not data.startswith('open:'):
        return

    key = data[5:]
    p = get_entry(context, key)
    if p is None:
        await q.message.reply_text('⚠️ Selection expired or access denied. Please browse again.', parse_mode="HTML")
        return

    try:
        if p.is_dir():
            text, markup = directory_view(context, p, page=0)
            await render_or_edit(q, text, markup)
        elif p.is_file():
            # Show rich file information card with Download button
            text, markup = file_details_view(context, p)
            await render_or_edit(q, text, markup)
    except Exception as exc:
        log.warning("Open item failed for %s: %s", p, exc)
        await q.message.reply_text(f"⚠️ Unable to open item: {html.escape(str(exc))}", parse_mode="HTML")


async def post_init(application: Application):
    """Set native Telegram Bot menu commands and send startup notification."""
    try:
        commands = [
            BotCommand("start", "Open PC Dashboard & Drives"),
            BotCommand("browse", "Explore drives and folders"),
            BotCommand("shortcuts", "Quick access (Desktop, Downloads, Docs)"),
            BotCommand("search", "Search for files by name"),
            BotCommand("status", "Check PC performance, RAM & uptime"),
            BotCommand("help", "Help and information")
        ]
        await application.bot.set_my_commands(commands)
    except Exception as e:
        log.warning("Could not set bot commands: %s", e)

    try:
        startup_msg = (
            f"🟢 <b>{html.escape(DEVICE_NAME)} is now ONLINE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Ready for remote file access. Send /start or tap a button below to explore:"
        )
        await application.bot.send_message(
            chat_id=AUTHORIZED_ID,
            text=startup_msg,
            reply_markup=MAIN_KEYBOARD,
            parse_mode="HTML"
        )
    except Exception as e:
        log.warning("Could not send startup notification: %s", e)


def main():
    try:
        check_and_acquire_pid()
        log.info('Bot starting; %d detected/authorized drive root(s)', len(ROOTS))

        request_handler = HTTPXRequest(httpx_kwargs={'verify': False})
        app = (
            Application.builder()
            .token(TOKEN)
            .request(request_handler)
            .post_init(post_init)
            .build()
        )

        commands = [
            ('start', start_cmd),
            ('help', start_cmd),
            ('drives', drives_cmd),
            ('folders', drives_cmd),
            ('browse', drives_cmd),
            ('shortcuts', shortcuts_cmd),
            ('download', download_cmd),
            ('status', status_cmd),
            ('search', search_cmd),
        ]
        for name, handler in commands:
            app.add_handler(CommandHandler(name, handler))

        app.add_handler(CallbackQueryHandler(callback_handler))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))

        log.info('Bot initialized successfully with authorized user ID %s', AUTHORIZED_ID)
        stop_signals = None if os.name == 'nt' else (signal.SIGINT, signal.SIGTERM)
        while True:
            try:
                app.run_polling(drop_pending_updates=True, stop_signals=stop_signals)
                break
            except Exception as e:
                err_msg = str(e).lower()
                if "conflict" in err_msg or "terminated by other getupdates request" in err_msg:
                    log.warning("Another computer is currently active with this bot token. Standby mode: retrying in 20 seconds...")
                    time.sleep(20)
                else:
                    log.exception("Polling loop terminated unexpectedly: %s", e)
                    raise
            finally:
                log.info("Polling cycle ended.")
    except Exception as exc:
        log.exception("Fatal unhandled crash in bot main: %s", exc)
        raise


if __name__ == '__main__':
    main()
