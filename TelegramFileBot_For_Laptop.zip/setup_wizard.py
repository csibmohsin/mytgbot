"""
Setup and management wizard for Telegram Windows File Bot.
Provides first-run configuration, token validation against Telegram API,
Windows Task Scheduler registration, process management, and health checks.
"""

import sys
import os
import re
import json
import time
import ctypes
import urllib.request
import urllib.error
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
CONFIG_EXAMPLE_PATH = BASE_DIR / "config.example.json"
PID_PATH = BASE_DIR / "bot.pid"
TASK_NAME = "TelegramFileBot"


def is_windows() -> bool:
    return os.name == "nt"


def redact_token_in_string(text: str, token: str = "") -> str:
    """Sanitize any telegram token from text strings."""
    if token and token in text:
        text = text.replace(token, "[REDACTED_TOKEN]")
    return re.sub(r'bot\d+:[A-Za-z0-9_-]+', 'bot[REDACTED_TOKEN]', text)


def test_telegram_token(token: str, timeout: int = 10) -> tuple[bool, str, dict]:
    """
    Test the bot token against Telegram's getMe endpoint.
    Returns (success, message, user_info).
    Never exposes token in exception or error messages.
    """
    token = token.strip()
    if not token or token.startswith("REPLACE_"):
        return False, "Token is empty or still set to template placeholder.", {}

    if not re.match(r'^\d+:[A-Za-z0-9_-]{30,}$', token):
        return False, "Token format is invalid. Expected format: 123456789:ABCdef...", {}

    url = f"https://api.telegram.org/bot{token}/getMe"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "TelegramFileBot-Setup/1.0"},
        method="GET"
    )

    import ssl
    contexts = [None]
    try:
        contexts.append(ssl._create_unverified_context())
    except Exception:
        pass

    last_err = "Unknown error"
    for ctx in contexts:
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as response:
                if response.status == 200:
                    payload = json.loads(response.read().decode("utf-8"))
                    if payload.get("ok"):
                        result = payload.get("result", {})
                        username = result.get("username", "Unknown")
                        first_name = result.get("first_name", "Bot")
                        return True, f"Verified bot @{username} ({first_name})", result
                    return False, f"Telegram API returned error: {payload.get('description')}", {}
        except urllib.error.HTTPError as e:
            if e.code == 401 or e.code == 404:
                return False, "Telegram returned HTTP 401/404: Bot token is invalid or does not exist.", {}
            return False, f"Telegram API HTTP error {e.code}", {}
        except urllib.error.URLError as e:
            last_err = str(e.reason)
            if "CERTIFICATE_VERIFY_FAILED" in last_err and ctx is None:
                # Try unverified context next
                continue
            return False, f"Network error connecting to api.telegram.org: {last_err}", {}
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
            return False, f"Connection failed: {last_err}", {}

    return False, f"Could not verify token: {last_err}", {}


def get_process_by_pid(pid: int) -> bool:
    """Check if process with given PID exists and is a Python process on Windows."""
    if pid <= 0:
        return False
    if not is_windows():
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    h_process = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h_process:
        return False
    try:
        exit_code = ctypes.c_ulong()
        if not ctypes.windll.kernel32.GetExitCodeProcess(h_process, ctypes.byref(exit_code)):
            return False
        if exit_code.value != STILL_ACTIVE:
            return False
        buf = ctypes.create_unicode_buffer(1024)
        size = ctypes.c_ulong(len(buf))
        if ctypes.windll.kernel32.QueryFullProcessImageNameW(h_process, 0, buf, ctypes.byref(size)):
            return "python" in buf.value.lower()
        return True
    finally:
        ctypes.windll.kernel32.CloseHandle(h_process)


def get_running_bot_pid() -> int | None:
    """Return PID if bot is currently running, otherwise None."""
    if not PID_PATH.exists():
        return None
    try:
        data = json.loads(PID_PATH.read_text(encoding="utf-8"))
        pid = int(data.get("pid", 0))
        if pid > 0 and get_process_by_pid(pid):
            return pid
        # Stale PID file
        try:
            PID_PATH.unlink()
        except OSError:
            pass
        return None
    except Exception:
        try:
            PID_PATH.unlink()
        except OSError:
            pass
        return None


def start_bot_background() -> tuple[bool, str, int | None]:
    """Launch the bot in a detached Windows background process."""
    running_pid = get_running_bot_pid()
    if running_pid:
        return False, f"Bot is already running (PID: {running_pid}).", running_pid

    venv_py = BASE_DIR / ".venv" / "Scripts" / "python.exe"
    bot_script = BASE_DIR / "bot.py"

    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200
    creationflags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP if is_windows() else 0

    try:
        proc = subprocess.Popen(
            [str(venv_py), str(bot_script)],
            cwd=str(BASE_DIR),
            creationflags=creationflags,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True
        )
    except Exception as e:
        return False, f"Failed to spawn bot process: {e}", None

    # Wait up to 3 seconds for bot to initialize and write PID
    for _ in range(6):
        time.sleep(0.5)
        pid = get_running_bot_pid()
        if pid:
            return True, f"Bot started successfully (PID: {pid}).", pid

    # If PID file wasn't written yet, check if process is still alive
    if proc.poll() is None:
        return True, f"Bot process launched (PID: {proc.pid}).", proc.pid

    return False, "Bot process exited immediately. Check bot.log for details.", None


def stop_bot() -> bool:
    """Stop the running bot process gracefully, then forcefully if needed."""
    pid = get_running_bot_pid()
    stopped = False

    if pid:
        print(f"Stopping bot process (PID: {pid})...")
        try:
            subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True)
            time.sleep(1)
            if get_process_by_pid(pid):
                subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
            stopped = True
            print(f"[OK] Process {pid} terminated.")
        except Exception as e:
            print(f"[ERROR] Failed to terminate process {pid}: {e}")
    else:
        print("[INFO] No running bot process found.")

    if PID_PATH.exists():
        try:
            PID_PATH.unlink()
        except OSError:
            pass

    # Also stop scheduled task instance if running
    if is_windows():
        try:
            subprocess.run(
                ["schtasks", "/End", "/TN", TASK_NAME],
                capture_output=True,
                check=False
            )
        except Exception:
            pass

    return stopped


def is_task_scheduled() -> bool:
    """Check if the Windows scheduled task exists."""
    if not is_windows():
        return False
    try:
        res = subprocess.run(
            ["schtasks", "/Query", "/TN", TASK_NAME],
            capture_output=True,
            text=True
        )
        return res.returncode == 0
    except Exception:
        return False


def install_scheduled_task() -> bool:
    """Register per-user Windows Task Scheduler task to run at logon."""
    if not is_windows():
        print("[ERROR] Task Scheduler is only available on Windows.")
        return False

    venv_pythonw = BASE_DIR / ".venv" / "Scripts" / "pythonw.exe"
    bot_script = BASE_DIR / "bot.py"

    if not venv_pythonw.exists():
        print(f"[ERROR] pythonw.exe not found at {venv_pythonw}. Setup virtual environment first.")
        return False

    target_cmd = f'"{venv_pythonw}" "{bot_script}"'

    cmd = [
        "schtasks", "/Create",
        "/TN", TASK_NAME,
        "/TR", target_cmd,
        "/SC", "ONLOGON",
        "/F",
        "/IT"
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode == 0:
            print(f"[OK] Windows Scheduled Task '{TASK_NAME}' registered successfully.")
            print("The bot will automatically start in the background whenever you sign in to Windows.")
            return True
        else:
            print(f"[ERROR] Failed to register scheduled task: {res.stderr.strip()}")
            return False
    except Exception as e:
        print(f"[ERROR] Exception creating scheduled task: {e}")
        return False


def remove_scheduled_task() -> bool:
    """Unregister the Windows Task Scheduler task."""
    if not is_windows():
        return False

    cmd = ["schtasks", "/Delete", "/TN", TASK_NAME, "/F"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode == 0:
            print(f"[OK] Windows Scheduled Task '{TASK_NAME}' removed.")
            return True
        else:
            if "The system cannot find the file specified" in res.stderr or res.returncode == 1:
                print(f"[INFO] Task '{TASK_NAME}' was not registered.")
                return True
            print(f"[ERROR] Failed to delete scheduled task: {res.stderr.strip()}")
            return False
    except Exception as e:
        print(f"[ERROR] Exception removing scheduled task: {e}")
        return False


def load_config() -> tuple[dict | None, str]:
    """Load config.json and return (config_dict, error_message)."""
    if not CONFIG_PATH.exists():
        return None, "config.json does not exist."
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        token = str(data.get("bot_token", "")).strip()
        uid = data.get("authorized_user_id")

        if not token or token.startswith("REPLACE_"):
            return None, "bot_token is missing or set to placeholder."
        try:
            uid_int = int(uid)
            if uid_int <= 0:
                return None, "authorized_user_id must be a positive integer."
        except (ValueError, TypeError):
            return None, "authorized_user_id is not a valid number."

        return data, ""
    except json.JSONDecodeError as e:
        return None, f"config.json is not valid JSON: {e}"
    except Exception as e:
        return None, f"Failed to read config.json: {e}"


def interactive_wizard() -> bool:
    """Interactive wizard to configure the Telegram Bot."""
    print("=" * 60)
    print("      Telegram Windows File Bot - Configuration Wizard      ")
    print("=" * 60)
    print()

    existing_config, _ = load_config()
    existing_token = existing_config.get("bot_token", "") if existing_config else ""
    existing_uid = existing_config.get("authorized_user_id", "") if existing_config else ""
    existing_auto = existing_config.get("auto_detect_drives", True) if existing_config else True

    # 1. Telegram Bot Token
    token = ""
    while True:
        if existing_token and not existing_token.startswith("REPLACE_"):
            masked_token = existing_token[:6] + "..." + existing_token[-4:]
            print(f"Current Bot Token: {masked_token}")
            choice = input("Keep existing token? [Y/n]: ").strip().lower()
            if choice != "n":
                token = existing_token
                break

        print("\nStep 1: Enter your Telegram Bot Token")
        print("  - Open Telegram and message @BotFather")
        print("  - Use /newbot to create a bot or /token to retrieve your token")
        print("  - Token looks like: 123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ")
        print("  - (Input is NOT logged or transmitted anywhere except api.telegram.org)")
        raw_token = input("\nEnter Bot Token: ").strip()

        if not raw_token:
            print("[!] Token cannot be empty. Try again.")
            continue

        print("\nVerifying token with Telegram API...")
        ok, msg, bot_info = test_telegram_token(raw_token)
        if ok:
            print(f"[OK] {msg}")
            token = raw_token
            break
        else:
            print(f"[!] Validation failed: {msg}")
            retry = input("Would you like to try entering the token again? [Y/n]: ").strip().lower()
            if retry == "n":
                print("[!] Setup aborted by user.")
                return False

    # 2. Authorized Telegram User ID
    uid = 0
    while True:
        if existing_uid and int(existing_uid) > 0:
            print(f"\nCurrent Authorized User ID: {existing_uid}")
            choice = input("Keep existing User ID? [Y/n]: ").strip().lower()
            if choice != "n":
                uid = int(existing_uid)
                break

        print("\nStep 2: Enter your Numeric Telegram User ID")
        print("  - The bot will ONLY respond to this specific user ID.")
        print("  - You can find your ID by messaging @userinfobot on Telegram.")
        print("  - It is a number like: 1247536922")
        raw_uid = input("\nEnter Numeric User ID: ").strip()

        try:
            parsed_uid = int(raw_uid)
            if parsed_uid <= 0:
                print("[!] User ID must be a positive number.")
                continue
            uid = parsed_uid
            break
        except ValueError:
            print("[!] Invalid number. Please enter digits only.")

    # 3. Drive Detection
    print("\nStep 3: Storage Access Mode")
    print("  - Option A: Auto-detect all mounted Windows drive roots (C:\\, D:\\, etc.)")
    print("  - Option B: Restrict to specific folders listed in config.json")
    auto_choice = input(f"Enable auto-detect for all available drives? [Y/n] (default: Y): ").strip().lower()
    auto_detect = (auto_choice != "n")

    # Save to config.json
    config_data = {
        "bot_token": token,
        "authorized_user_id": uid,
        "auto_detect_drives": auto_detect,
        "allowed_folders": existing_config.get("allowed_folders", []) if existing_config else []
    }

    try:
        CONFIG_PATH.write_text(json.dumps(config_data, indent=2), encoding="utf-8")
        print("\n[OK] Configuration saved successfully to config.json.")
    except Exception as e:
        print(f"[ERROR] Failed to save config.json: {e}")
        return False

    # 4. Optional Scheduled Task Setup
    print("\nStep 4: Automatic Startup on Windows Sign-in")
    is_sched = is_task_scheduled()
    if is_sched:
        print("[INFO] Automatic startup task 'TelegramFileBot' is currently ENABLED.")
        toggle = input("Keep automatic startup enabled? [Y/n]: ").strip().lower()
        if toggle == "n":
            remove_scheduled_task()
    else:
        print("[INFO] Automatic startup is currently DISABLED.")
        sched_choice = input("Enable automatic startup when you sign in to Windows? [y/N]: ").strip().lower()
        if sched_choice == "y":
            install_scheduled_task()

    print("\n" + "=" * 60)
    print("                  Setup Complete!                  ")
    print("=" * 60)
    return True


def print_status():
    """Print overall status of the bot, environment, and task."""
    print("=" * 60)
    print("             Telegram Windows File Bot Status             ")
    print("=" * 60)

    print(f"OS: {os.name} (Windows: {is_windows()})")
    print(f"Working Directory: {BASE_DIR}")
    print(f"Python Interpreter: {sys.executable}")
    print(f"Python Version: {sys.version.split()[0]}")

    cfg, err = load_config()
    if cfg:
        masked_token = cfg['bot_token'][:6] + "..." + cfg['bot_token'][-4:]
        print(f"Config: Valid")
        print(f"  - Bot Token: {masked_token}")
        print(f"  - Authorized User ID: {cfg['authorized_user_id']}")
        print(f"  - Auto Detect Drives: {cfg['auto_detect_drives']}")
    else:
        print(f"Config: INVALID ({err})")

    pid = get_running_bot_pid()
    if pid:
        print(f"Process: RUNNING (PID: {pid})")
    else:
        print("Process: STOPPED")

    sched = is_task_scheduled()
    print(f"Startup Task: {'ENABLED (Registered in Task Scheduler)' if sched else 'DISABLED'}")
    print("=" * 60)


def main():
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()
        if arg in ("--wizard", "-w"):
            success = interactive_wizard()
            sys.exit(0 if success else 1)
        elif arg in ("--verify", "-v"):
            cfg, err = load_config()
            if not cfg:
                print(f"[FAIL] Configuration check failed: {err}")
                sys.exit(1)
            ok, msg, _ = test_telegram_token(cfg["bot_token"])
            if not ok:
                print(f"[FAIL] Telegram token verification failed: {msg}")
                sys.exit(1)
            print(f"[OK] Configuration and Telegram connection valid: {msg}")
            sys.exit(0)
        elif arg == "--install-task":
            success = install_scheduled_task()
            sys.exit(0 if success else 1)
        elif arg == "--uninstall-task":
            success = remove_scheduled_task()
            sys.exit(0 if success else 1)
        elif arg == "--stop":
            stopped = stop_bot()
            sys.exit(0 if stopped else 1)
        elif arg == "--start":
            ok, msg, pid = start_bot_background()
            print(f"[{'OK' if ok else 'INFO'}] {msg}")
            sys.exit(0 if ok else 1)
        elif arg == "--check-running":
            pid = get_running_bot_pid()
            if pid:
                print(f"RUNNING:{pid}")
                sys.exit(0)
            else:
                print("STOPPED")
                sys.exit(1)
        elif arg in ("--status", "-s"):
            print_status()
            sys.exit(0)

    # Default action: check configuration
    cfg, err = load_config()
    if not cfg:
        print(f"[INFO] Initial configuration required: {err}")
        success = interactive_wizard()
        sys.exit(0 if success else 1)
    else:
        ok, msg, _ = test_telegram_token(cfg["bot_token"], timeout=8)
        if ok:
            print(f"[OK] Configuration verified: {msg}")
        else:
            print(f"[INFO] Using configured settings: {msg}")
        sys.exit(0)

    sys.exit(0)


if __name__ == "__main__":
    main()
